package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 8/1/2016.
 */
@WebFilter(filterName = "DisplayOccupationalProfileFilter")
public class DisplayOccupationalProfileFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=(String)req.getServletContext().getAttribute("username");
        String password=(String)req.getServletContext().getAttribute("password");
        String status="false";
        String name=req.getParameter("name");
        String email=req.getParameter("email");
        String companyName=req.getParameter("companyName");
        String profile=req.getParameter("profile");
        if(username!=null && password!=null)
        {
            if(name!=null && email!=null && companyName!=null && profile!=null)
            {
                status="true";
                req.setAttribute("name",name);
                req.setAttribute("email",email);
                req.setAttribute("companyName",companyName);
                req.setAttribute("profile",profile);
            }
            else
            {
                status="false";
            }
        }
        req.getServletContext().setAttribute("status",status);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
