package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

/**
 * Created by arpitm on 7/29/2016.
 */
@WebServlet(name = "CreateAccount")
public class CreateAccount extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher requestDispatcher;
        if(request.getServletContext().getAttribute("status").equals("false"))
        {
            //username already exists
            requestDispatcher=request.getRequestDispatcher("Signup.jsp");
            requestDispatcher.include(request,response);
            requestDispatcher=request.getRequestDispatcher("UsernameAlreadyExists.html");
            requestDispatcher.include(request,response);
        }
        else
        {
            if(request.getServletContext().getAttribute("status").equals("goToLoginForm"))
            {
                requestDispatcher=request.getRequestDispatcher("index.jsp");
                requestDispatcher.forward(request,response);
            }
            String username=(String)request.getServletContext().getAttribute("username");
            String password=(String)request.getServletContext().getAttribute("password");
            HashMap<String,String> usernameAndPasswords;
            if(request.getServletContext().getAttribute("usernameAndPasswords")!=null)
            {
                usernameAndPasswords=(HashMap<String, String>) request.getServletContext().getAttribute("usernameAndPasswords");
            }
            else
            {
                usernameAndPasswords=new HashMap<>();
            }
            usernameAndPasswords.put(username,password);
            request.getServletContext().setAttribute("usernameAndPasswords",usernameAndPasswords);
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.include(request, response);
            requestDispatcher=request.getRequestDispatcher("AccountSuccessfullyCreated.html");
            requestDispatcher.include(request,response);
        }

    }
}