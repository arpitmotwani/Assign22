package com.bitwise.test.beans;

/**
 * Created by arpitm on 8/1/2016.
 */
public class EducationalProfileBean {
    private String recentEducationalQualification;
    private String passingYear;
    private String schoolOrCollegeName;
    private String cgpaOrPercentage;

    public void setRecentEducationalQualification(String recentEducationalQualification) {
        this.recentEducationalQualification = recentEducationalQualification;
    }

    public void setPassingYear(String passingYear) {
        this.passingYear = passingYear;
    }

    public void setSchoolOrCollegeName(String schoolOrCollegeName) {
        this.schoolOrCollegeName = schoolOrCollegeName;
    }

    public void setCgpaOrPercentage(String cgpaOrPercentage) {
        this.cgpaOrPercentage = cgpaOrPercentage;
    }

    public String getRecentEducationalQualification() {
        return recentEducationalQualification;
    }

    public String getPassingYear() {
        return passingYear;
    }

    public String getSchoolOrCollegeName() {
        return schoolOrCollegeName;
    }

    public String getCgpaOrPercentage() {
        return cgpaOrPercentage;
    }

}
