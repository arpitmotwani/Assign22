package com.viralpatel;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {

    private static List<User> users=new ArrayList<>();
    static
    {
        users.add(new User("Amit","Sharma"));
        users.add(new User("Shreya","Pandey"));
        users.add(new User("Pinku","Tiwari"));
        users.add(new User("Shikhar","Dhawan"));
        users.add(new User("Ramlal","Kushwah"));
    }

    @RequestMapping(value="/index", method=RequestMethod.GET)
    public String index(@ModelAttribute("model") ModelMap model)
    {
        model.addAttribute("user",new User());
        model.addAttribute("users",users);
        return "index";
    }
    @RequestMapping(value="/add", method=RequestMethod.POST)
    public String add(@ModelAttribute("user") User user, ModelMap model)
    {
        System.out.println(user.getFirstName()+"->"+user.getLastName());
        if(user.getFirstName()!=null && user.getLastName()!=null)
        {
            System.out.println("here");
            users.add(new User(user.getFirstName(),user.getLastName()));
        }
        model.addAttribute("user",user);
        model.addAttribute("users",users);
        return "redirect:/index";
    }
}