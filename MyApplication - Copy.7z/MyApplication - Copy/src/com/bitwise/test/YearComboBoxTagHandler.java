package com.bitwise.test;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;

/**
 * Created by arpitm on 8/1/2016.
 */
public class YearComboBoxTagHandler extends TagSupport {
    public int doStartTag() throws JspException {
        try {
            JspWriter writer = pageContext.getOut();
            writer.write("<select id=\"passingYear\" name=\"passingYear\" class=\"form-control\">");
            writer.write("<option value=\"2010\">2010</option>");
            writer.write("<option value=\"2011\">2011</option>");
            writer.write("<option value=\"2012\">2012</option>");
            writer.write("<option value=\"2013\">2013</option>");
            writer.write("<option value=\"2014\">2014</option>");
            writer.write("<option value=\"2015\">2015</option>");
            writer.write("<option value=\"2016\">2016</option>");
            writer.write("</select>");
        }catch(IOException ioe)
        {
            System.out.println(ioe);
        }
        return super.SKIP_BODY;
    }
}