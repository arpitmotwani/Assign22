package com.bitwise.test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;

/**
 * Created by Arpit on 7/31/2016.
 */
public class CityComboBoxTagHandler extends TagSupport {
    public int doStartTag() throws JspException{
        try {
            JspWriter writer = pageContext.getOut();
            writer.write("<select class=\"cityComboBox form-control\" name=\"city\"  id=\"city\">");
            writer.write("<option value=\"Pune\">Pune</option>");
            writer.write("<option value=\"Nagpur\">Nagpur</option>");
            writer.write("<option value=\"Mumbai\">Mumbai</option>");
            writer.write("<option value=\"Lonawala\">Lonawala</option>");
            writer.write("<option value=\"Bhopal\">Bhopal</option>");
            writer.write("</select>");
        }catch(IOException ioe)
        {
            System.out.println(ioe);
        }
        return super.SKIP_BODY;
    }
}