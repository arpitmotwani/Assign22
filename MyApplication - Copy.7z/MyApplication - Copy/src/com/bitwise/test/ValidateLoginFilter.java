package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Arpit on 7/30/2016.
 */
@WebFilter(filterName = "ValidateLoginFilter")
public class ValidateLoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=req.getParameter("loginUsername");
        String password=req.getParameter("loginPassword");
        String status="false";
        if(username!=null && password!=null)
        {
            if(req.getServletContext().getAttribute("usernameAndPasswords")!=null)
            {
                HashMap<String,String> usernameAndPasswords=(HashMap<String,String>)req.getServletContext().getAttribute("usernameAndPasswords");
                ArrayList<String> hashmapUsername=new ArrayList<String>(usernameAndPasswords.keySet());
                ArrayList<String> hashmapPassword=new ArrayList<String>(usernameAndPasswords.values());
                    int x=0;
                    while(x<usernameAndPasswords.size())
                    {
                        //System.out.println(hashmapUsername);
                        if(hashmapUsername.get(x).equals(username) && hashmapPassword.get(x).equals(password))
                        {
                            status="true";
                            break;
                        }
                        x++;
                    }
                }

            else
            {
                status="false";
            }
        }
        else
        {
            status="goToLoginPage";
        }
        req.getServletContext().setAttribute("status",status);
        req.getServletContext().setAttribute("username",username);
        req.getServletContext().setAttribute("password",password);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
